require('dotenv').config();
const { Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType } = require('discord.js');
const keepAlive = require('./keep_alive');

// Initialize the bot client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Channel],
});

const PANEL_CHANNEL_NAME = 'pannel';
const TEMP_VOICE_CHANNEL_PREFIX = 'Temp-VC';

// Keep the bot alive
keepAlive();

// Bot ready event
client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
});

// When the bot joins a new server
client.on('guildCreate', async (guild) => {
  try {
    console.log(`Joined a new guild: ${guild.name}`);

    // Check if the panel channel already exists
    const existingChannel = guild.channels.cache.find((channel) => channel.name === PANEL_CHANNEL_NAME);

    if (existingChannel) {
      console.log('Panel channel already exists.');
      return;
    }

    // Create the panel channel
    const panelChannel = await guild.channels.create({
      name: PANEL_CHANNEL_NAME,
      type: 0, // 0 represents a text channel
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id, // Default role
          allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'],
        },
      ],
    });

    console.log(`Created panel channel: ${panelChannel.name}`);

    // Send the panel message
    await sendPanelMessage(panelChannel);
    console.log('Panel message sent successfully.');
  } catch (error) {
    console.error(`Error in guildCreate event: ${error.message}`);
  }
});

// Function to send the panel message
async function sendPanelMessage(channel) {
  try {
    const embed = new EmbedBuilder()
      .setTitle('VoiceMate Panel')
      .setDescription('Manage your temporary voice channels using the buttons below.')
      .setColor('#5865F2');

    // Split buttons into two rows (max 5 buttons per row)
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('create').setLabel('Create').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('bitrate').setLabel('Bitrate').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('lock').setLabel('Lock').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('unlock').setLabel('Unlock').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('hide').setLabel('Hide').setStyle(ButtonStyle.Danger)
    );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('unhide').setLabel('Unhide').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('rename').setLabel('Rename').setStyle(ButtonStyle.Primary)
    );

    await channel.send({ embeds: [embed], components: [row1, row2] });
  } catch (error) {
    console.error(`Error sending panel message: ${error.message}`);
  }
}

// Handle button interactions
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const user = interaction.user;
  const guild = interaction.guild;

  switch (interaction.customId) {
    case 'create': {
      const modal = new ModalBuilder()
        .setCustomId('create_voice_channel')
        .setTitle('Create Voice Channel');

      const channelNameInput = new TextInputBuilder()
        .setCustomId('channel_name')
        .setLabel('Enter the name for your voice channel:')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const actionRow = new ActionRowBuilder().addComponents(channelNameInput);
      modal.addComponents(actionRow);

      await interaction.showModal(modal);
      break;
    }

    case 'bitrate': {
      const modal = new ModalBuilder()
        .setCustomId('set_bitrate')
        .setTitle('Set Voice Channel Bitrate');

      const bitrateInput = new TextInputBuilder()
        .setCustomId('bitrate_value')
        .setLabel('Enter the bitrate (kbps):')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const actionRow = new ActionRowBuilder().addComponents(bitrateInput);
      modal.addComponents(actionRow);

      await interaction.showModal(modal);
      break;
    }

    case 'lock': {
      const userVC = getUserVoiceChannel(guild, user);
      if (!userVC) {
        await interaction.reply({ content: 'You are not connected to any voice channel.', ephemeral: true });
        return;
      }

      await userVC.permissionOverwrites.edit(guild.roles.everyone, { Connect: false });
      await interaction.reply({ content: `Voice channel '${userVC.name}' has been locked.`, ephemeral: true });
      break;
    }

    case 'unlock': {
      const userVC = getUserVoiceChannel(guild, user);
      if (!userVC) {
        await interaction.reply({ content: 'You are not connected to any voice channel.', ephemeral: true });
        return;
      }

      await userVC.permissionOverwrites.edit(guild.roles.everyone, { Connect: true });
      await interaction.reply({ content: `Voice channel '${userVC.name}' has been unlocked.`, ephemeral: true });
      break;
    }

    case 'hide': {
      const userVC = getUserVoiceChannel(guild, user);
      if (!userVC) {
        await interaction.reply({ content: 'You are not connected to any voice channel.', ephemeral: true });
        return;
      }

      await userVC.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: false });
      await interaction.reply({ content: `Voice channel '${userVC.name}' has been hidden.`, ephemeral: true });
      break;
    }

    case 'unhide': {
      const userVC = getUserVoiceChannel(guild, user);
      if (!userVC) {
        await interaction.reply({ content: 'You are not connected to any voice channel.', ephemeral: true });
        return;
      }

      await userVC.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: true });
      await interaction.reply({ content: `Voice channel '${userVC.name}' is now visible.`, ephemeral: true });
      break;
    }

    case 'rename': {
      const modal = new ModalBuilder()
        .setCustomId('rename_channel')
        .setTitle('Rename Voice Channel');

      const renameInput = new TextInputBuilder()
        .setCustomId('new_channel_name')
        .setLabel('Enter the new name for your voice channel:')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      const actionRow = new ActionRowBuilder().addComponents(renameInput);
      modal.addComponents(actionRow);

      await interaction.showModal(modal);
      break;
    }
  }
});

// Handle modal submissions
client.on('interactionCreate', async (interaction) => {
  if (interaction.type !== InteractionType.ModalSubmit) return;

  const guild = interaction.guild;
  const user = interaction.user;

  switch (interaction.customId) {
    case 'create_voice_channel': {
      const channelName = interaction.fields.getTextInputValue('channel_name');

      const category = guild.channels.cache.find((c) => c.type === 4); // Category channel
      const voiceChannel = await guild.channels.create({
        name: channelName,
        type: 2, // Voice channel
        parent: category ? category.id : null,
      });

      await interaction.reply({ content: `Voice channel '${channelName}' created successfully!`, ephemeral: true });

      // Monitor the channel and delete it after 30 seconds of inactivity
      monitorChannel(voiceChannel);
      break;
    }

    case 'set_bitrate': {
      const bitrateValue = interaction.fields.getTextInputValue('bitrate_value');

      const userVC = getUserVoiceChannel(guild, user);
      if (!userVC) {
        await interaction.reply({ content: 'You are not connected to any voice channel.', ephemeral: true });
        return;
      }

      try {
        const bitrate = parseInt(bitrateValue) * 1000;
        await userVC.setBitrate(bitrate);

        await interaction.reply({ content: `Bitrate updated to ${bitrateValue} kbps.`, ephemeral: true });
      } catch (error) {
        await interaction.reply({ content: 'Invalid bitrate value. Please enter a number.', ephemeral: true });
      }
      break;
    }

    case 'rename_channel': {
      const newName = interaction.fields.getTextInputValue('new_channel_name');

      const userVC = getUserVoiceChannel(guild, user);
      if (!userVC) {
        await interaction.reply({ content: 'You are not connected to any voice channel.', ephemeral: true });
        return;
      }

      await userVC.setName(newName);
      await interaction.reply({ content: `Voice channel renamed to '${newName}'.`, ephemeral: true });
      break;
    }
  }
});

// Helper function to monitor and delete inactive channels
async function monitorChannel(channel) {
  const interval = setInterval(async () => {
    if (!channel || channel.members.size === 0) {
      clearInterval(interval);
      await channel.delete();
    }
  }, 30000);
}

// Helper function to get the user's voice channel
function getUserVoiceChannel(guild, user) {
  return guild.channels.cache.find((channel) => channel.type === 2 && channel.members.has(user.id));
}

// Login the bot
client.login(process.env.TOKEN);